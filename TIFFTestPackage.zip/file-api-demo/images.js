window.onload = function() {

		var fileInput = document.getElementById('fileInput');
		var fileDisplayArea = document.getElementById('fileDisplayArea');


		fileInput.addEventListener('change', function(e) {
			var file = fileInput.files[0];
			var imageType = /image.*/;
		//file.type.match(imageType)
			if (false) {
				var reader = new FileReader();

				reader.onload = function(e) {
					fileDisplayArea.innerHTML = "";

					var img = new Image();
					img.src = reader.result;

					fileDisplayArea.appendChild(img);
				}

				reader.readAsDataURL(file);	
			} else {
				alert("XXX2");
				var reader = new FileReader();
				reader.onload = function(e) {
						Tiff.initialize({
              TOTAL_MEMORY: 100000000
            });
            var tiff = new Tiff({
              buffer: e.target.result
            });
            alert(tiff.countDirectory())
                for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
      						tiff.setDirectory(i);
      						var canvas = tiff.toCanvas();
      						alert(canvas);
      						fileDisplayArea.appendChild(canvas);
    						}
    			}			
    			reader.readAsArrayBuffer(file);
			}
		});

}
